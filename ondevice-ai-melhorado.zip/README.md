# 🤖 OnDevice AI - Interface Melhorada

App de IA 100% on-device usando Llama 3.2 1B via React Native ExecuTorch, com interface moderna e menu de chats.

## ✨ Novidades

- 🎨 **Tema escuro moderno** - Interface dark com acentos em teal
- 📂 **Menu de chats** - Drawer lateral com lista de conversas
- ✏️ **Renomear/Excluir** - Segure um chat para ver opções
- 💬 **Input moderno** - Estilo WhatsApp/ChatGPT com botão de envio circular
- ⌨️ **Keyboard Avoiding** - Input sobe junto com o teclado (iOS e Android)
- 🧠 **Sugestões** - Chips de sugestão na tela inicial
- ⏳ **Loading animado** - Tela de carregamento do modelo com progresso

## 📁 Estrutura

```
├── App.tsx                 # Navegação Drawer
├── index.tsx               # Entry point
├── src/
│   ├── context/
│   │   └── ChatContext.tsx # Gerenciamento de estado dos chats
│   ├── screens/
│   │   ├── ChatScreen.tsx  # Tela principal de chat
│   │   └── ChatListScreen.tsx # Menu lateral de conversas
│   ├── styles.ts           # Estilos globais
│   └── types.ts            # Tipos TypeScript
├── .github/workflows/
│   └── build-apk.yml       # Workflow GitHub Actions
└── assets/                 # Imagens do app
```

## 🚀 Como usar

### 1. Instalar dependências

```bash
yarn install
# ou
npm install
```

### 2. Rodar no Android

```bash
npx expo run:android
```

### 3. Build APK local

```bash
npx expo prebuild --clean

cd android
./gradlew assembleRelease
```

O APK ficará em: `android/app/build/outputs/apk/release/app-release.apk`

## 🔧 GitHub Actions - Build Automático

O workflow está em `.github/workflows/build-apk.yml`. Para usar:

### Passo 1: Subir para o GitHub

```bash
git init
git add .
git commit -m "Primeiro commit"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/SEU_REPO.git
git push -u origin main
```

### Passo 2: Configurar Secrets (se necessário)

Se seu app usa alguma chave de API ou certificado de assinatura, adicione em:
**Settings → Secrets and variables → Actions**

### Passo 3: Disparar o build

O build roda automaticamente em:
- Todo `push` para `main` ou `master`
- Todo `pull_request` para `main` ou `master`
- Manualmente em **Actions → Build Android APK → Run workflow**

### Passo 4: Baixar o APK

Vá em **Actions → último workflow → Artifacts** e baixe `app-release-apk`.

Ou, se ativou o release automático, vá em **Releases** do repositório.

## ⚠️ Importante

- O modelo LLM é baixado na primeira execução (pode levar minutos)
- O app requer ~1.5GB de espaço para o modelo
- Funciona 100% offline após o download inicial
- Certifique-se de ter o Android SDK e NDK configurados

## 📋 Requisitos

- Node.js 20+
- Java 17
- Android SDK
- Yarn ou npm

## 📝 Licença

MIT
