import { StyleSheet, Dimensions } from 'react-native'

const { width: SCREEN_WIDTH } = Dimensions.get('window')

export const styles = StyleSheet.create({
  // ===== CONTAINER & LAYOUT =====
  container: {
    flex: 1,
    backgroundColor: '#0a0a0f',
  },

  // ===== HEADER =====
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: Platform.OS === 'ios' ? 50 : 16,
    paddingHorizontal: 16,
    paddingBottom: 12,
    backgroundColor: '#0f0f1a',
    borderBottomWidth: 1,
    borderBottomColor: '#1a1a2e',
  },
  menuButton: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: '#1a1a2e',
    justifyContent: 'center',
    alignItems: 'center',
  },
  menuIcon: {
    color: '#ccd6f6',
    fontSize: 20,
  },
  headerTitleContainer: {
    flex: 1,
    marginHorizontal: 12,
  },
  headerTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 2,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#64ffda',
    marginRight: 6,
  },
  statusText: {
    fontSize: 11,
    color: '#64ffda',
  },
  newChatHeaderButton: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: '#1a1a2e',
    justifyContent: 'center',
    alignItems: 'center',
  },
  newChatIcon: {
    color: '#ccd6f6',
    fontSize: 18,
  },

  // ===== LOADING =====
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#0a0a0f',
  },
  loadingCard: {
    backgroundColor: '#0f0f1a',
    borderRadius: 20,
    padding: 32,
    alignItems: 'center',
    width: '100%',
    maxWidth: 320,
    borderWidth: 1,
    borderColor: '#1a1a2e',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 10,
  },
  loadingEmoji: {
    fontSize: 56,
    marginBottom: 16,
  },
  loadingTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 8,
  },
  loadingSubtext: {
    fontSize: 14,
    color: '#8892b0',
    textAlign: 'center',
    lineHeight: 20,
  },
  loader: {
    marginTop: 20,
  },
  progressBar: {
    width: '100%',
    height: 4,
    backgroundColor: '#1a1a2e',
    borderRadius: 2,
    marginTop: 20,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#64ffda',
    borderRadius: 2,
  },
  errorText: {
    color: '#ff6b6b',
    textAlign: 'center',
    marginTop: 12,
    fontSize: 13,
  },

  // ===== MESSAGES =====
  messagesContainer: {
    flex: 1,
  },
  messagesContent: {
    flexGrow: 1,
    padding: 16,
    paddingBottom: 24,
  },

  // Empty State
  emptyStateContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
    minHeight: 400,
  },
  emptyStateEmoji: {
    fontSize: 64,
    marginBottom: 20,
  },
  emptyStateTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#8892b0',
    textAlign: 'center',
    paddingHorizontal: 30,
    lineHeight: 20,
  },
  suggestionContainer: {
    marginTop: 24,
    width: '100%',
    paddingHorizontal: 20,
  },
  suggestionChip: {
    backgroundColor: '#0f0f1a',
    borderWidth: 1,
    borderColor: '#1a1a2e',
    borderRadius: 12,
    padding: 14,
    marginVertical: 6,
    alignItems: 'center',
  },
  suggestionText: {
    color: '#ccd6f6',
    fontSize: 14,
  },

  // Message Bubbles
  messageContainer: {
    marginBottom: 16,
    maxWidth: SCREEN_WIDTH * 0.85,
  },
  userMessageContainer: {
    alignSelf: 'flex-end',
  },
  assistantMessageContainer: {
    alignSelf: 'flex-start',
  },
  messageBubble: {
    padding: 14,
    borderRadius: 18,
  },
  userMessageContainer: {
    alignSelf: 'flex-end',
  },
  assistantMessageContainer: {
    alignSelf: 'flex-start',
  },
  messageHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  messageRole: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64ffda',
  },
  messageTime: {
    fontSize: 10,
    color: '#8892b0',
  },
  messageText: {
    fontSize: 15,
    lineHeight: 22,
    color: '#ccd6f6',
  },
  userMessageText: {
    color: '#fff',
  },

  // Generating indicator
  generatingContainer: {
    flexDirection: 'row',
    alignSelf: 'flex-start',
    marginLeft: 16,
    marginBottom: 16,
    padding: 12,
    backgroundColor: '#0f0f1a',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#1a1a2e',
  },
  generatingDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#64ffda',
    marginHorizontal: 3,
    opacity: 0.4,
  },
  generatingDotDelay1: {
    opacity: 0.7,
  },
  generatingDotDelay2: {
    opacity: 1,
  },

  // ===== INPUT =====
  inputWrapper: {
    backgroundColor: '#0f0f1a',
    borderTopWidth: 1,
    borderTopColor: '#1a1a2e',
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: Platform.OS === 'ios' ? 28 : 16,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    backgroundColor: '#1a1a2e',
    borderRadius: 24,
    borderWidth: 1,
    borderColor: '#2a2a3e',
    paddingHorizontal: 16,
    paddingVertical: 8,
    minHeight: 52,
    maxHeight: 120,
  },
  textInput: {
    flex: 1,
    color: '#fff',
    fontSize: 15,
    lineHeight: 20,
    paddingTop: 8,
    paddingBottom: 8,
    maxHeight: 100,
    textAlignVertical: 'top',
  },
  sendButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#64ffda',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
    marginBottom: 2,
  },
  sendButtonDisabled: {
    backgroundColor: '#1a1a2e',
    borderWidth: 1,
    borderColor: '#2a2a3e',
  },
  sendButtonIcon: {
    color: '#0a0a0f',
    fontSize: 14,
    fontWeight: 'bold',
    marginLeft: 2,
  },
  inputHint: {
    textAlign: 'center',
    fontSize: 11,
    color: '#8892b0',
    marginTop: 8,
  },
})
