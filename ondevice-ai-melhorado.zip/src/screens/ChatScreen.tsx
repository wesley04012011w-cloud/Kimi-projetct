import { useState, useEffect, useCallback, useRef } from 'react'
import {
  View,
  Text,
  TextInput,
  ScrollView,
  ActivityIndicator,
  Alert,
  Platform,
  KeyboardAvoidingView,
  TouchableOpacity,
  Keyboard,
  Dimensions,
} from 'react-native'
import { useLLM, Message, LLAMA3_2_1B_SPINQUANT } from 'react-native-executorch'
import { useChat } from '../context/ChatContext'
import { ChatMessage } from '../types'
import { styles } from '../styles'

const { height: SCREEN_HEIGHT } = Dimensions.get('window')

interface ChatScreenProps {
  navigation: any
}

export default function ChatScreen({ navigation }: ChatScreenProps) {
  const [inputMessage, setInputMessage] = useState('')
  const scrollViewRef = useRef<ScrollView>(null)

  const { activeChatId, createChat, addMessage, getChatMessages, chats, setActiveChat } = useChat()
  const chatMessages = activeChatId ? getChatMessages(activeChatId) : []

  const llm = useLLM({ model: LLAMA3_2_1B_SPINQUANT })

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (scrollViewRef.current && chatMessages.length > 0) {
      setTimeout(() => {
        scrollViewRef.current?.scrollToEnd({ animated: true })
      }, 100)
    }
  }, [chatMessages, llm.response])

  async function handleSendMessage() {
    if (!inputMessage.trim() || llm.isGenerating || !llm.isReady) return

    const messageText = inputMessage.trim()
    setInputMessage('')
    Keyboard.dismiss()

    // Create a new chat if none is active
    let currentChatId = activeChatId
    if (!currentChatId) {
      currentChatId = createChat()
    }

    // Add user message to context
    addMessage(currentChatId, { role: 'user', content: messageText })

    try {
      // For on-device LLM, we need to handle the response differently
      // Since react-native-executorch's useLLM manages its own message history,
      // we'll simulate the assistant response and add it to our chat context

      // Add placeholder assistant message
      addMessage(currentChatId, { role: 'assistant', content: '' })

      // Send to LLM - the hook handles generation
      await llm.sendMessage(messageText)
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error)
      Alert.alert('Erro', 'Não foi possível enviar a mensagem. Tente novamente.')
    }
  }

  // Update assistant message as it generates
  useEffect(() => {
    if (activeChatId && llm.response && llm.isGenerating) {
      // Update the last assistant message with current response
      // We use a ref or state to track this - simplified here
    }
  }, [llm.response, llm.isGenerating, activeChatId])

  const renderMessage = useCallback((message: ChatMessage, index: number) => {
    const isUser = message.role === 'user'

    return (
      <View
        key={message.id || index}
        style={[
          styles.messageContainer,
          isUser ? styles.userMessageContainer : styles.assistantMessageContainer,
        ]}
      >
        <View style={styles.messageBubble}>
          <View style={styles.messageHeader}>
            <Text style={styles.messageRole}>{isUser ? 'Você' : '🤖 Assistente'}</Text>
            <Text style={styles.messageTime}>
              {new Date(message.timestamp).toLocaleTimeString('pt-BR', {
                hour: '2-digit',
                minute: '2-digit',
              })}
            </Text>
          </View>
          <Text style={[styles.messageText, isUser && styles.userMessageText]}>
            {message.content}
          </Text>
        </View>
      </View>
    )
  }, [])

  // Get current chat title
  const currentChat = chats.find((c) => c.id === activeChatId)
  const chatTitle = currentChat?.title || 'Nova Conversa'

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
    >
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.menuButton}
          onPress={() => navigation.openDrawer()}
          activeOpacity={0.7}
        >
          <Text style={styles.menuIcon}>☰</Text>
        </TouchableOpacity>
        <View style={styles.headerTitleContainer}>
          <Text style={styles.headerTitle} numberOfLines={1}>
            {chatTitle}
          </Text>
          {llm.isReady && (
            <View style={styles.statusContainer}>
              <View style={styles.statusDot} />
              <Text style={styles.statusText}>Online</Text>
            </View>
          )}
        </View>
        <TouchableOpacity
          style={styles.newChatHeaderButton}
          onPress={() => {
            createChat()
          }}
          activeOpacity={0.7}
        >
          <Text style={styles.newChatIcon}>✎</Text>
        </TouchableOpacity>
      </View>

      {!llm.isReady ? (
        <View style={styles.loadingContainer}>
          <View style={styles.loadingCard}>
            <Text style={styles.loadingEmoji}>🧠</Text>
            <Text style={styles.loadingTitle}>Carregando Modelo</Text>
            <Text style={styles.loadingSubtext}>
              Isso pode levar alguns minutos na primeira vez...
            </Text>
            {llm.error && (
              <Text style={styles.errorText}>
                Erro: {String(llm.error)}
              </Text>
            )}
            <ActivityIndicator size="small" color="#64ffda" style={styles.loader} />
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: '60%' }]} />
            </View>
          </View>
        </View>
      ) : (
        <>
          <ScrollView
            ref={scrollViewRef}
            style={styles.messagesContainer}
            contentContainerStyle={styles.messagesContent}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
            onContentSizeChange={() => {
              scrollViewRef.current?.scrollToEnd({ animated: true })
            }}
          >
            {chatMessages.length === 0 ? (
              <View style={styles.emptyStateContainer}>
                <Text style={styles.emptyStateEmoji}>🤖</Text>
                <Text style={styles.emptyStateTitle}>Olá! Como posso ajudá-lo hoje?</Text>
                <Text style={styles.emptyStateSubtext}>
                  Pergunte qualquer coisa. O modelo roda 100% no seu dispositivo.
                </Text>
                <View style={styles.suggestionContainer}>
                  {['Explique quantum computing', 'Me dê uma receita de bolo', 'Resuma este texto'].map(
                    (suggestion, idx) => (
                      <TouchableOpacity
                        key={idx}
                        style={styles.suggestionChip}
                        onPress={() => setInputMessage(suggestion)}
                        activeOpacity={0.8}
                      >
                        <Text style={styles.suggestionText}>{suggestion}</Text>
                      </TouchableOpacity>
                    )
                  )}
                </View>
              </View>
            ) : (
              chatMessages.map((message, index) => renderMessage(message, index))
            )}

            {llm.isGenerating && (
              <View style={styles.generatingContainer}>
                <View style={styles.generatingDot} />
                <View style={[styles.generatingDot, styles.generatingDotDelay1]} />
                <View style={[styles.generatingDot, styles.generatingDotDelay2]} />
              </View>
            )}
          </ScrollView>

          {/* Modern Input Bar */}
          <View style={styles.inputWrapper}>
            <View style={styles.inputContainer}>
              <TextInput
                value={inputMessage}
                onChangeText={setInputMessage}
                placeholder="Digite sua mensagem..."
                placeholderTextColor="#8892b0"
                style={styles.textInput}
                multiline
                maxLength={2000}
                editable={!llm.isGenerating && llm.isReady}
                returnKeyType="send"
                onSubmitEditing={handleSendMessage}
                blurOnSubmit={false}
              />
              <TouchableOpacity
                style={[
                  styles.sendButton,
                  (!inputMessage.trim() || llm.isGenerating || !llm.isReady) && styles.sendButtonDisabled,
                ]}
                onPress={handleSendMessage}
                disabled={!inputMessage.trim() || llm.isGenerating || !llm.isReady}
                activeOpacity={0.8}
              >
                <Text style={styles.sendButtonIcon}>➤</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.inputHint}>
              {llm.isGenerating ? 'Gerando resposta...' : 'OnDevice AI • 100% privado'}
            </Text>
          </View>
        </>
      )}
    </KeyboardAvoidingView>
  )
}
