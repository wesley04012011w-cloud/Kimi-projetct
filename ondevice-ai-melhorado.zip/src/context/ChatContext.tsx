import React, { createContext, useContext, useState, useCallback } from 'react'
import { v4 as uuidv4 } from 'uuid'
import { Chat, ChatMessage } from '../types'

interface ChatContextType {
  chats: Chat[]
  activeChatId: string | null
  createChat: () => string
  deleteChat: (id: string) => void
  setActiveChat: (id: string | null) => void
  addMessage: (chatId: string, message: Omit<ChatMessage, 'id' | 'timestamp'>) => void
  updateLastMessage: (chatId: string, content: string) => void
  getChatMessages: (chatId: string) => ChatMessage[]
  renameChat: (id: string, title: string) => void
}

const ChatContext = createContext<ChatContextType | undefined>(undefined)

export function ChatProvider({ children }: { children: React.ReactNode }) {
  const [chats, setChats] = useState<Chat[]>([])
  const [activeChatId, setActiveChatId] = useState<string | null>(null)

  const createChat = useCallback(() => {
    const newChat: Chat = {
      id: uuidv4(),
      title: 'Nova Conversa',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    }
    setChats((prev) => [newChat, ...prev])
    setActiveChatId(newChat.id)
    return newChat.id
  }, [])

  const deleteChat = useCallback((id: string) => {
    setChats((prev) => prev.filter((chat) => chat.id !== id))
    if (activeChatId === id) {
      setActiveChatId(null)
    }
  }, [activeChatId])

  const setActiveChat = useCallback((id: string | null) => {
    setActiveChatId(id)
  }, [])

  const addMessage = useCallback(
    (chatId: string, message: Omit<ChatMessage, 'id' | 'timestamp'>) => {
      const newMessage: ChatMessage = {
        ...message,
        id: uuidv4(),
        timestamp: Date.now(),
      }
      setChats((prev) =>
        prev.map((chat) =>
          chat.id === chatId
            ? {
                ...chat,
                messages: [...chat.messages, newMessage],
                updatedAt: Date.now(),
                title:
                  chat.messages.length === 0 && message.role === 'user'
                    ? message.content.slice(0, 30) + (message.content.length > 30 ? '...' : '')
                    : chat.title,
              }
            : chat
        )
      )
    },
    []
  )

  const updateLastMessage = useCallback((chatId: string, content: string) => {
    setChats((prev) =>
      prev.map((chat) =>
        chat.id === chatId
          ? {
              ...chat,
              messages: chat.messages.map((msg, idx) =>
                idx === chat.messages.length - 1 && msg.role === 'assistant'
                  ? { ...msg, content }
                  : msg
              ),
              updatedAt: Date.now(),
            }
          : chat
      )
    )
  }, [])

  const getChatMessages = useCallback(
    (chatId: string) => {
      const chat = chats.find((c) => c.id === chatId)
      return chat?.messages || []
    },
    [chats]
  )

  const renameChat = useCallback((id: string, title: string) => {
    setChats((prev) =>
      prev.map((chat) => (chat.id === id ? { ...chat, title } : chat))
    )
  }, [])

  return (
    <ChatContext.Provider
      value={{
        chats,
        activeChatId,
        createChat,
        deleteChat,
        setActiveChat,
        addMessage,
        updateLastMessage,
        getChatMessages,
        renameChat,
      }}
    >
      {children}
    </ChatContext.Provider>
  )
}

export function useChat() {
  const context = useContext(ChatContext)
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider')
  }
  return context
}
