import { useState } from 'react'
import { NavigationContainer } from '@react-navigation/native'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { ChatProvider } from './src/context/ChatContext'
import ChatScreen from './src/screens/ChatScreen'
import ChatListScreen from './src/screens/ChatListScreen'

const Stack = createNativeStackNavigator()

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <ChatProvider>
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Chat">
            {(props) => (
              <ChatScreen
                {...props}
                navigation={{
                  ...props.navigation,
                  openDrawer: () => setMenuOpen(true),
                }}
              />
            )}
          </Stack.Screen>
        </Stack.Navigator>
      </NavigationContainer>

      {menuOpen && (
        <ChatListScreen
          navigation={{
            closeDrawer: () => setMenuOpen(false),
            navigate: (name: string) => {
              setMenuOpen(false)
            },
          }}
        />
      )}
    </ChatProvider>
  )
}