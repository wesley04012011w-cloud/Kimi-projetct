# Assets

Coloque aqui seus arquivos de imagem:

- `icon.png` - Ícone do app (1024x1024)
- `splash.png` - Tela de splash (1242x2436)
- `adaptive-icon.png` - Ícone adaptativo Android (1024x1024)
- `favicon.png` - Favicon web (48x48)

Você pode usar o [Expo Icon Generator](https://icon.kitchen/) para gerar todos de uma vez.
