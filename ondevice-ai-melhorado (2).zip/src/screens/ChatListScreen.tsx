import React from 'react'
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Alert,
} from 'react-native'
import { useChat } from '../context/ChatContext'
import { Chat } from '../types'

interface ChatListScreenProps {
  navigation: any
}

export default function ChatListScreen({ navigation }: ChatListScreenProps) {
  const { chats, activeChatId, setActiveChat, createChat, deleteChat, renameChat } = useChat()

  const handleChatPress = (chatId: string) => {
    setActiveChat(chatId)
    navigation.closeDrawer()
  }

  const handleNewChat = () => {
    createChat()
    navigation.closeDrawer()
  }

  const handleLongPress = (chat: Chat) => {
    Alert.alert(
      'Opções',
      chat.title,
      [
        {
          text: 'Renomear',
          onPress: () => {
            Alert.prompt(
              'Renomear Conversa',
              'Digite o novo nome:',
              (text) => {
                if (text?.trim()) renameChat(chat.id, text.trim())
              },
              'plain-text',
              chat.title
            )
          },
        },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: () => deleteChat(chat.id),
        },
        { text: 'Cancelar', style: 'cancel' },
      ]
    )
  }

  const renderChatItem = ({ item }: { item: Chat }) => {
    const isActive = item.id === activeChatId
    const date = new Date(item.updatedAt).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'short',
    })

    return (
      <TouchableOpacity
        style={[styles.chatItem, isActive && styles.chatItemActive]}
        onPress={() => handleChatPress(item.id)}
        onLongPress={() => handleLongPress(item)}
        activeOpacity={0.7}
      >
        <View style={styles.chatIcon}>
          <Text style={styles.chatIconText}>💬</Text>
        </View>
        <View style={styles.chatInfo}>
          <Text style={[styles.chatTitle, isActive && styles.chatTitleActive]} numberOfLines={1}>
            {item.title}
          </Text>
          <Text style={styles.chatDate}>{date}</Text>
        </View>
        {isActive && <View style={styles.activeIndicator} />}
      </TouchableOpacity>
    )
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Conversas</Text>
        <Text style={styles.headerSubtitle}>{chats.length} chat(s)</Text>
      </View>

      <TouchableOpacity style={styles.newChatButton} onPress={handleNewChat} activeOpacity={0.8}>
        <Text style={styles.newChatIcon}>➕</Text>
        <Text style={styles.newChatText}>Nova Conversa</Text>
      </TouchableOpacity>

      <FlatList
        data={chats}
        keyExtractor={(item) => item.id}
        renderItem={renderChatItem}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyIcon}>🤖</Text>
            <Text style={styles.emptyText}>Nenhuma conversa ainda</Text>
            <Text style={styles.emptySubtext}>Toque em "Nova Conversa" para começar</Text>
          </View>
        }
      />

      <View style={styles.footer}>
        <Text style={styles.footerText}>OnDevice AI v1.0</Text>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1a1a2e',
  },
  header: {
    paddingTop: 60,
    paddingHorizontal: 20,
    paddingBottom: 20,
    backgroundColor: '#16213e',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  headerSubtitle: {
    fontSize: 13,
    color: '#8892b0',
    marginTop: 4,
  },
  newChatButton: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: 16,
    padding: 14,
    backgroundColor: '#0f3460',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#1f4e79',
  },
  newChatIcon: {
    fontSize: 18,
    marginRight: 10,
  },
  newChatText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
  },
  listContent: {
    paddingHorizontal: 12,
    paddingBottom: 20,
  },
  chatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    marginVertical: 4,
    borderRadius: 10,
    backgroundColor: '#16213e',
  },
  chatItemActive: {
    backgroundColor: '#0f3460',
    borderWidth: 1,
    borderColor: '#1f4e79',
  },
  chatIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#1a1a2e',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  chatIconText: {
    fontSize: 16,
  },
  chatInfo: {
    flex: 1,
  },
  chatTitle: {
    color: '#ccd6f6',
    fontSize: 14,
    fontWeight: '500',
  },
  chatTitleActive: {
    color: '#fff',
    fontWeight: '600',
  },
  chatDate: {
    color: '#8892b0',
    fontSize: 11,
    marginTop: 2,
  },
  activeIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#64ffda',
    marginLeft: 8,
  },
  emptyContainer: {
    alignItems: 'center',
    marginTop: 40,
    paddingHorizontal: 20,
  },
  emptyIcon: {
    fontSize: 48,
    marginBottom: 12,
  },
  emptyText: {
    color: '#ccd6f6',
    fontSize: 16,
    fontWeight: '500',
  },
  emptySubtext: {
    color: '#8892b0',
    fontSize: 13,
    marginTop: 6,
    textAlign: 'center',
  },
  footer: {
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#16213e',
    alignItems: 'center',
  },
  footerText: {
    color: '#8892b0',
    fontSize: 12,
  },
})
