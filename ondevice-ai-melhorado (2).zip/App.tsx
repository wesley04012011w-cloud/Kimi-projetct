import 'react-native-gesture-handler'
import { NavigationContainer } from '@react-navigation/native'
import { createDrawerNavigator } from '@react-navigation/drawer'
import { ChatProvider } from './src/context/ChatContext'
import ChatScreen from './src/screens/ChatScreen'
import ChatListScreen from './src/screens/ChatListScreen'

const Drawer = createDrawerNavigator()

function ChatListDrawer(props: any) {
  return <ChatListScreen {...props} />
}

export default function App() {
  return (
    <ChatProvider>
      <NavigationContainer>
        <Drawer.Navigator
          drawerContent={(props) => <ChatListDrawer {...props} />}
          screenOptions={{
            headerShown: false,
            drawerStyle: {
              width: 300,
              backgroundColor: '#1a1a2e',
            },
            overlayColor: 'rgba(0,0,0,0.7)',
            drawerType: 'front',
            swipeEdgeWidth: 80,
          }}
        >
          <Drawer.Screen name="Chat" component={ChatScreen} />
        </Drawer.Navigator>
      </NavigationContainer>
    </ChatProvider>
  )
}
